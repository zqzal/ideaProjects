package com._9;

/**
 * Created by xuxi on 2018/11/23.
 */
public abstract class DisplayImpl {

    public abstract void rawOpen();
    public abstract void rawPrint();
    public abstract void rawClose();

}
